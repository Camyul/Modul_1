﻿namespace Academy.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    public enum Track
    {
        none = 0,
        Frontend = 1,
        Dev = 2

    }
}
