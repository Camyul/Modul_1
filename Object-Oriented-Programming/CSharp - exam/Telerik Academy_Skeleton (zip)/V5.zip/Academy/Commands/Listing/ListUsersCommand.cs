﻿using Academy.Models.Contracts;
using System.Collections.Generic;

namespace Academy.Commands.Listing
{
    static class ListUsersCommand
    {
        //public static IList<IStudent> OnsiteStudents(this IList<IStudent> collection) 
        //{                                           
            
        //    collection.Add
        //    return collection
        //}

    }
}
