﻿namespace Academy.Commands.Listing
{
    class ListUsersCommand
    {
        // TODO: Implement this
    }
}
