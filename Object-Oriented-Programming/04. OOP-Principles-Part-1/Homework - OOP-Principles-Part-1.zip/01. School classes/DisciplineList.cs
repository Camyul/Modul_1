﻿namespace School_classes
{
    public enum DisciplineList
    {
        Mathematic,
        Physics,
        Boilogy,
        Chemistry,
        English,
        Spanish,
        Programming,
        Cooking,
        Geography,
        Sport,
        History
    }
}
