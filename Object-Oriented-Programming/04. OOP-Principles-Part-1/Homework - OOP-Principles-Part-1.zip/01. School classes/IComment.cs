﻿namespace School_classes
{
    public interface IComment  //Interface to Add Free Text Block
    {
        void AddComent(string comment); 
        
    }
}
