﻿namespace Animal_hierarchy
{
    public enum Gender
    {
        Female,
        Male
    }
}
