﻿namespace Animal_hierarchy
{
    public interface ISound
    {
        void Sound();
    }
}
